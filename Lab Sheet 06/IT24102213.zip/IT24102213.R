setwd("C:\\Users\\User\\Desktop\\IT24102213\\Lab 6")
# Distribution
# X ~ Binomial(n = 50, p = 0.85)

# Probability P(X >= 47)
1 - pbinom(46, 50, 0.85)




# Distribution
# X ~ Poisson(lambda = 12)

# Probability P(X = 15)
dpois(15, 12)
